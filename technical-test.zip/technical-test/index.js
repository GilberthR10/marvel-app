const prompt = require('prompt-sync')({sigint: true});

const exercise1 = require('./src/exercise-1.js');
const exercise2 = require('./src/exercise-2.js');


const main = () => {
    const input = parseInt(prompt('Which exercise do you want to execute? (1 or 2): '));
    
    switch (input) {
        case 1:
            exercise1.main();
            break;
        case 2:
            exercise2.main();
            break;
        default:
            console.log('Invalid exercise number');
            break;
    }
}


main();
