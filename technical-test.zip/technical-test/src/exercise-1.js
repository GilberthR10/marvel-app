/*
Ejercicio 1 (2pts)
Crear un script (javascript/nodejs) que reciba un rango entre A y B y a partir de este rango se muestren en pantalla los números primos.

En matemáticas, un número primo es un número natural mayor que 1 que tiene únicamente dos divisores positivos distintos: él mismo y el 1.

Ej: Para el rango entre 1 y 10, los números primos serán 2,3,5 y 7.

El entregable puede ser un script que se pueda ejecutar por terminal o una web simple sin diseño.
*/

const prompt = require('prompt-sync')({sigint: true});


const isPrime = (number) => {
    for (let i = 2; i < number; i++) {
        if (number % i === 0) {
            return false;
        }
    }
    return true;
}


const getPrimeNumbers = (a, b) => {
    const range = [...Array(b - a + 1).keys()].map(x => x + a);
    return range.filter(n => n > 1).filter(n => isPrime(n))
}


const main = () => {
    console.log('Enter the range between A and B');
    const a = parseInt(prompt('A: '));
    const b = parseInt(prompt('B: '));

    if (a < 0 || b < 0) {
        console.log('Numbers must be positive');
        return;
    }

    if(a > b) {
        console.log('Invalid range');
        return;
    }

    primeNumbers = getPrimeNumbers(a, b);
    console.log('Prime numbers: ', primeNumbers);
}


module.exports = { main };
