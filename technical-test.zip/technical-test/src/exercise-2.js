/*
Ejercicio 2 (3pts)
Dado los siguientes json:​
*/

// JSON
let values = {
  1: {
    carrier: "CCH",
    service: "DEX",
  },
  2: {
    carrier: "CCH",
    service: "express",
  },
  3: {
    carrier: "CCH",
    service: "priority",
  },
  15: {
    carrier: "CHP",
    service: "nextday",
  },
  16: {
    carrier: "CHP",
    service: "sameday",
  },
  17: {
    carrier: "CHP",
    service: "express",
  },
};
// JSON
let json = {
  data: {
    BUIN: [
      {
        limit: 1,
        over_carrier_service_id: 17,
        under_carrier_service_id: 17,
      },
      {
        limit: 2,
        over_carrier_service_id: 15,
        under_carrier_service_id: 15,
      },
    ],
    LAJA: [
      {
        limit: 2,
        over_carrier_service_id: 1,
        under_carrier_service_id: 1,
      },
      {
        limit: 5,
        over_carrier_service_id: 2,
        under_carrier_service_id: 2,
      },
      {
        limit: 1,
        over_carrier_service_id: 17,
        under_carrier_service_id: 17,
      },
    ],

    LEBU: [
      {
        limit: 2,
        over_carrier_service_id: 1,
        under_carrier_service_id: 1,
      },
      {
        limit: 6,
        over_carrier_service_id: 3,
        under_carrier_service_id: 3,
      },
      {
        limit: 5,
        over_carrier_service_id: 2,
        under_carrier_service_id: 2,
      },
      {
        limit: 4,
        over_carrier_service_id: 16,
        under_carrier_service_id: 16,
      },
    ],

    LOTA: [
      {
        limit: 2,
        over_carrier_service_id: 15,
        under_carrier_service_id: 15,
      },
      {
        limit: 4,
        over_carrier_service_id: 16,
        under_carrier_service_id: 16,
      },
      {
        limit: 1,
        over_carrier_service_id: 17,
        under_carrier_service_id: 17,
      },
    ],
  },
};

/*
        Se debe generar un script que con estas entradas genere el siguiente resultado:

Los servicios para cada localidad con mayor limite:
        */

let result = {
  BUIN: {
    limit: 2,
    over: {
      carrier: "CHP",
      service: "nextday",
    },
    under: {
      carrier: "CHP",
      service: "nextday",
    },
  },
  LAJA: {
    limit: 5,
    over: {
      carrier: "CCH",
      service: "express",
    },
    under: {
      carrier: "CCH",
      service: "express",
    },
  },
  LEBU: {
    limit: 6,
    over: {
      carrier: "CCH",
      service: "priority",
    },
    under: {
      carrier: "CCH",
      service: "priority",
    },
  },
  LOTA: {
    limit: 4,
    over: {
      carrier: "CHP",
      service: "sameday",
    },
    under: {
      carrier: "CHP",
      service: "sameday",
    },
  },
};

/* Debe además identificar:

La localidad con mayor cantidad de servicios disponibles
El servicio con mayor cobertura (Usado en más localidades)
El script debe estar escrito en javascript (puedes usar librerías/frameworks que te ayuden con la manipulación de los json), el entregable puede ser un script por terminal o una web simple. */

const getHighestLimitLocations = (data) => {
  const locations = Object.entries(data).map(([key, value]) => ({name: key, services: value}));

  const mappedLocations = locations.map(location => ({
    ...location,
    services: location.services.map(service => ({
      limit: service.limit,
      over: values[service.over_carrier_service_id],
      under: values[service.under_carrier_service_id]
    }))
  }));
  
  return mappedLocations.map(location => ({
    ...location,
    services: location.services.sort((a, b) => b.limit - a.limit)[0]
  }));
}


const getReducedHighestLimitLocations = (locations) => {
  return locations.reduce((location, item) => ({
      ...location,
      [item.name]: item.services
    }), {}
  );
}


const getHighestLimitLocation = (locations) => {
  return locations.sort((a, b) => b.services.limit - a.services.limit)[0];
}


const main = () => {
  const highestLimitLocations = getHighestLimitLocations(json.data);

  const reducedHighestLimitLocations = getReducedHighestLimitLocations(highestLimitLocations);
  console.log('- Los servicios para cada localidad con mayor limite: ', reducedHighestLimitLocations);

  const highestLimitLocation = getHighestLimitLocation(highestLimitLocations);
  console.log('- La localidad con mayor cantidad de servicios disponibles: ', highestLimitLocation.name);

  console.log('- El servicio con mayor cobertura (Usado en más localidades): ', highestLimitLocation.services.over.service);
}


module.exports = { main };
